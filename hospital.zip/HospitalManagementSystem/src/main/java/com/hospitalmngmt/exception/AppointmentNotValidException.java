package com.hospitalmngmt.exception;

public class AppointmentNotValidException extends Exception {
	public AppointmentNotValidException (String msg) {
		super(msg);
	}
}
